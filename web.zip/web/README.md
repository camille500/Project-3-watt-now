# Project-3-watt-now

## Table of contents
- [Concept](#concept)
- [live link](#live)
- [Todo/wishlist](#todo)

## Concept
We are letting the user be part of the sustainabilty movement . The bycicles are connected to an adaptor that stores the energie. The adoptor has an energiemeter that measures how much energie is generated and sends the data throught the nodeMCU to the server. The event organizer sets a goal for that day. During the day the user gets realtime feedback of the progression that is made. The user gets to see a tree that will fill and updates every 30 seconds, and alternately the user gets to see videos and information about how much influance the CO2 saving is having on the sustainabilty. The deadline ends every day at 20.00 and if the goal is met within a 10% range there should be a an show reveal and a a confettie cannon.

## <a name="live"></a>Live link

- [link](#https://p3-wottnow.herokuapp.com/)


## <a name="started"></a>Getting started

Clone the repo and install the dependencies with
`$ npm install`

To start the app run
`$ npm run start`

Create your own .env file with these variables:

```
MONGODB_URI=<consumer_key>
SESSIONSECRET=<consumer_secret>
```

### <a name="todo"></a> Todo/wishlist
-  [D3 tree visualisation]
De three visualisation is based on how much energy is generated through the users.

-  [servo motor + node MCU]

